function getData()
{
    var get=new XMLHttpRequest(); 
    // api
    get.open('GET','http://localhost:7000/getdata')


    get.onreadystatechange=function()
    {
        if(get.status==200&&get.readyState==4)
        {
          document.getElementById('div').innerText=this.responseText;
        }
    }

    get.send();
}