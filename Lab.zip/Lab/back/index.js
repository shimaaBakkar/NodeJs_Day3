const express=require('express');
const fs=require("fs")
const app=express(); 
const cors=require('cors')

// var data=[{name:"ahmed",age:22},
// {name:"ali",age:22},
// {name:"negm",age:22},
// {name:"sayed",age:22}]
app.use(cors()); 
app.use(function(req,res,next)
{

console.log("hi in midelware")
    next();
})

app.get('/register',function(req,res)
{
    let data=JSON.parse( fs.readFileSync("index.html",'utf-8'))
    res.send('./front.html')

})
app.post('/register',function(req,res)
{
    res.send('hello world')
    // console.log()
    let firstName = ;
    let userName = ;
    let Password = ;

})


// app.use(express.urlencoded({extended:true}))
// app.get('/iti',function(req,res)
// {
//     res.send('iti');
    
// })
// app.get('/postdata',function(req,res)
// {
//     console.log(req.query)
//     res.send("data is saved");
// })

// app.post('/postdata',function(req,res)
// {
//     console.log(req.body)
//     res.send(req.body);
// })

// app.get('/getdata',function(req,res)
// {
//         res.send(JSON.stringify(data));
// })
// app.get('/index',function(req,res)
// {
//         let html=fs.readFileSync("index.html",'utf-8');
//         res.send(html);
// })
// app.get('/data/:id',function(req,res)
// {
//     res.send(data[parseInt(req.params.id)])
// })

// app.put("/data/:id",function(req,res)
// {
//     console.log(req.body);
//     data[parseInt(req.params.id)].name=req.body.name;

//     res.send(JSON.stringify(data));
// })
// app.delete('/data/:id',function(req,res)
// {
//     data.splice(parseInt(req.params.id)-1,1);
//     res.send(JSON.stringify(data));
// })
// app.listen(7777,function()
// {
//     console.log('hi...')
// })